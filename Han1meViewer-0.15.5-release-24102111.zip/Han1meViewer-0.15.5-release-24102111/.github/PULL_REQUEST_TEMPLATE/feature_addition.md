---
name: "新功能添加"
about: "用於提交新功能的拉取請求"
title: "[FEATURE] <簡短描述>"
labels: "good idea | 好主意"
assignees: ""
---

### 功能描述

<!-- 請簡短描述你添加的新功能 -->