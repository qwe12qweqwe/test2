package com.yenaly.han1meviewer.ui.viewmodel

interface IHCsrfToken {
    var csrfToken: String?
}