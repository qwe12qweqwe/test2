---
name: "Bug 修復"
about: "用於提交 Bug 修復的拉取請求"
title: "[BUGFIX] <簡短描述>"
labels: "bug"
assignees: ""
---

### 描述

<!-- 請簡短描述你修復的 Bug -->

### 修復方法

<!-- 請描述你是如何修復這個 Bug 的 -->