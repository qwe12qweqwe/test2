plugins {
    `kotlin-dsl`
}

repositories {
    mavenCentral()
    google()
    maven("https://jitpack.io")
}